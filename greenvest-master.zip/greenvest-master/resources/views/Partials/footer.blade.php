<div class="" id="footer">
    <div class="container-fluid bg-dark pt-5 pb-5 ">
        <div class="container text-light">
            <div class="row mt-5">
                <div class="col-md-5 mb-5">
                    <img class="img-fluid" src="{{ asset('img/gv-text-light.png') }}" alt="" width="40%"
                        height="15%">
                </div>
                <div class="col">
                    <p>Home</p>
                    <p>Get Started</p>
                    <p>Support</p>
                </div>
                <div class="col">
                    <p>Green Sukuk</p>
                    <p>Green Bond</p>
                    <p>Green Taxonomy</p>
                </div>
                <div class="col">
                    <p>About Us</p>
                    <p>+ 000 000-00-00</p>
                </div>
            </div>

            <div class="row text-light mt-5 pt-5">
                <div class="col-md-12 mt-5">
                    <p class="" style="color: #d1d1d1">© 2022 GreenVest / Tim Bernice All rights reserved.</p>
                </div>
            </div>

        </div>
    </div>
</div>
