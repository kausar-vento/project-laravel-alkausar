@extends('navbar.nav_admin')

@section('navbar-admin')
    
<div class="card text-center">
    <div class="card-header">
        HAI, DAN
    </div>
    <div class="card-body">
        <a href="#" class="btn btn-primary">SELAMAT DATANG ADMIN</a>
    </div>
</div>

@endsection