

<?php $__env->startSection('navbar-admin'); ?>
    
<div class="card text-center">
    <div class="card-header">
        HAI, DAN
    </div>
    <div class="card-body">
        <a href="#" class="btn btn-primary">SELAMAT DATANG ADMIN</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\project_uts\resources\views/admin/index_admin.blade.php ENDPATH**/ ?>