

<?php $__env->startSection('navbar-admin'); ?>

<div class="card text-center">
    <div class="card-header">
        <a href="#" class="btn btn-primary">BRAND MEREK</a>
    </div>
</div>

<table class="table mt-5">
    <thead class="table-primary">
        <tr>
            <th scope="col">#</th>
            <th scope="col">First</th>
            <th scope="col">Last</th>
            <th scope="col">Handle</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\project_uts\resources\views/admin/kelola_brand_merek.blade.php ENDPATH**/ ?>