

<?php $__env->startSection('navbar-admin'); ?>

<div class="card text-center">
    <div class="card-header">
        <a href="#" class="btn btn-primary">ABOUT</a>
    </div>
</div>

<a href="/admin-about/create" class="btn btn-primary mt-3"><img src="https://img.icons8.com/material-outlined/24/000000/add.png" /> Tambah
    About</a>

<?php if(session()->has('success')): ?>
<div class="alert alert-success mt-3" role="alert">
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

<table class="table mt-2">
    <thead class="table-primary">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Judul</th>
            <th scope="col">Deskripsi</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($a->id); ?></th>
            <td><?php echo e($a-> judul); ?></td>
            <td class="text-truncate" style="max-width: 150px;"><?php echo e($a-> desc); ?></td>
            <td>
                <a class="badge bg-info" href="<?php echo e(route('admin-about.edit', $a->id)); ?>"><img
                        src="https://img.icons8.com/material-two-tone/24/000000/edit--v1.png" /></a>
                <form action="<?php echo e(route('admin-about.destroy', $a->id)); ?>" method="post" class="d-inline">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="badge bg-danger border-0" onclick="return confirm('Yakin Ingin Hapus About Ini?')"><img
                            style="width: 25px;"
                            src="https://img.icons8.com/fluency/48/000000/filled-trash.png" /></button>
                </form>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\project_uts\resources\views/admin/about/kelola_about.blade.php ENDPATH**/ ?>